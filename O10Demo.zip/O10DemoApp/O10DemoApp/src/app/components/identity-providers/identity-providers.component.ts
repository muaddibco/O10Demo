import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-identity-providers',
  templateUrl: './identity-providers.component.html',
  styleUrls: ['./identity-providers.component.scss']
})
export class IdentityProvidersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
