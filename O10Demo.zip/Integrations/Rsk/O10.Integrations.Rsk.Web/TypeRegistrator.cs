﻿using O10.Core.Architecture;

namespace O10.Integrations.Rsk.Web
{
    public class TypeRegistrator : TypeRegistratorBase
    {
    }
}
