﻿namespace O10.Client.Web.Portal.Dtos
{
    public class AttributeTransferDetails
    {
        public string Id { get; set; }
        public string PublicViewKey { get; set; }
        public string PublicSpendKey { get; set; }
        public string AccountInfo { get; set; }
    }
}
