﻿namespace O10.Client.Web.Portal.Dtos.ElectionCommittee
{
    public class RegisterPollDto
    {
        public string Name { get; set; }
    }
}
