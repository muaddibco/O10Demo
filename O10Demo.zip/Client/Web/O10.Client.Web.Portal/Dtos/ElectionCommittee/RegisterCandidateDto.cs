﻿namespace O10.Client.Web.Portal.Dtos.ElectionCommittee
{
    public class RegisterCandidateDto
    {
        public string Name { get; set; }
    }
}
