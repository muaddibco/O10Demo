﻿namespace O10.Client.Web.Portal.Dtos.ElectionCommittee
{
    public class PollDto
    {
        public long PollId { get; set; }

        public string Name { get; set; }
    }
}
