﻿namespace O10.Client.Web.Portal.Dtos.Scenarios
{
    public class ScenarioStepDto
    {
        public int Id { get; set; }
        public string Caption { get; set; }
    }
}
