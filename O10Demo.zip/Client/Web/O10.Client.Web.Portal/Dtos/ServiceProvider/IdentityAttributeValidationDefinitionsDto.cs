﻿using System.Collections.Generic;

namespace O10.Client.Web.Portal.Dtos.ServiceProvider
{
    public class IdentityAttributeValidationDefinitionsDto
    {
        public List<IdentityAttributeValidationDefinitionDto> IdentityAttributeValidationDefinitions { get; set; }
    }
}
