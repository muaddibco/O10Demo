﻿namespace O10.Client.Web.Portal.Dtos.ServiceProvider
{
    public class IdentityAttributeValidationDefinitionDto
    {
        public string SchemeName { get; set; }

        public string ValidationType { get; set; }

        public string CriterionValue { get; set; }
    }
}
