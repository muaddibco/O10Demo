﻿namespace O10.Client.Web.Portal.Dtos.ServiceProvider
{
    public class EmployeeGroupDto
    {
        public long GroupId { get; set; }
        public string GroupName { get; set; }
    }
}
