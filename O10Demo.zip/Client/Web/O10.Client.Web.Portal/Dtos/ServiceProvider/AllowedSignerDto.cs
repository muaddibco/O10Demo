﻿namespace O10.Client.Web.Portal.Dtos.ServiceProvider
{
    public class AllowedSignerDto
    {
        public long AllowedSignerId { get; set; }

        public string GroupOwner { get; set; }

        public string GroupName { get; set; }
    }
}
