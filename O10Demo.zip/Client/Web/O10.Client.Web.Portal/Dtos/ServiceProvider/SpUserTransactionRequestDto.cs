﻿namespace O10.Client.Web.Portal.Dtos.ServiceProvider
{
    public class SpUserTransactionRequestDto
    {
        public string RegistrationId { get; set; }
        public string Description { get; set; }
    }
}
