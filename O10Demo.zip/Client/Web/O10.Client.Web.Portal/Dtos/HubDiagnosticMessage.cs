﻿namespace O10.Client.Web.Portal.Dtos
{
    public class HubDiagnosticMessage
    {
        public string Message { get; set; }
    }
}
