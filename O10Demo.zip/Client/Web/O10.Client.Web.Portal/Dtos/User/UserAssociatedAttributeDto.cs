﻿namespace O10.Client.Web.Portal.Dtos.User
{
    public class UserAssociatedAttributeDto
    {
        public string AttributeName { get; set; }
        public string Alias { get; set; }
        public string Content { get; set; }
        public string ValueType { get; set; }
    }
}
