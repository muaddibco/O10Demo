﻿namespace O10.Client.Web.Portal.Dtos.User
{
    public class UserAttributeTransferWithValidationsDto
    {
        public UserAttributeTransferDto UserAttributeTransfer { get; set; }

        public string Password { get; set; }
    }
}
