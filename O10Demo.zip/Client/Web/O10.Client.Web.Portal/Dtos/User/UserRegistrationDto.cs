﻿namespace O10.Client.Web.Portal.Dtos.User
{
    public class UserRegistrationDto
    {
        public string UserRegistrationId { get; set; }
        public string Commitment { get; set; }
        public string Issuer { get; set; }
        public string AssetId { get; set; }
    }
}
