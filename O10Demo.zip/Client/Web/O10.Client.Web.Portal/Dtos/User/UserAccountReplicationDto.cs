﻿namespace O10.Client.Web.Portal.Dtos.User
{
    public class UserAccountReplicationDto
    {
        public long SourceAccountId { get; set; }

        public string AccountInfo { get; set; }
    }
}
