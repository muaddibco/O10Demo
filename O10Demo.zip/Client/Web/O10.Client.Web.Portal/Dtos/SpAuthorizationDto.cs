﻿namespace O10.Client.Web.Portal.Dtos
{
    public class SpAuthorizationDto
    {
        public string Token { get; set; }
    }
}
