﻿namespace O10.Client.Web.Portal.Dtos
{
    public class ErrorResponseDto
    {
        public string Message { get; set; }
    }
}
