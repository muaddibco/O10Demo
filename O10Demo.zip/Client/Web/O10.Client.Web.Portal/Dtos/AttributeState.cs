﻿namespace O10.Client.Web.Portal.Dtos
{
    public enum AttributeState
    {
        NotConfirmed,
        Confirmed,
        Disabled
    }
}
