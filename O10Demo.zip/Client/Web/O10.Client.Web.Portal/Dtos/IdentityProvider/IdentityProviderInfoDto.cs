﻿namespace O10.Client.Web.Portal.Dtos.IdentityProvider
{
    public class IdentityProviderInfoDto
    {
        public string Description { get; set; }

        public string Id { get; set; }

        public string Target { get; set; }
    }
}
