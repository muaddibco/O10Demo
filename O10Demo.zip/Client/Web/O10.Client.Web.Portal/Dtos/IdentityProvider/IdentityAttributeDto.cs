﻿namespace O10.Client.Web.Portal.Dtos.IdentityProvider
{
    public class IdentityAttributeDto
    {
        public string AttributeName { get; set; }
        public string Content { get; set; }
        public string OriginatingCommitment { get; set; }
    }
}
