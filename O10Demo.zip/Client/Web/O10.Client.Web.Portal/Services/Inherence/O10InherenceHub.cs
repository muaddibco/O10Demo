﻿using O10.Client.Web.Common.Hubs;

namespace O10.Client.Web.Portal.Services.Inherence
{
    public class O10InherenceHub : HubBase
    {
    }
}
