﻿namespace O10.Client.Web.Portal.ElectionCommittee.Models
{
    public enum PollState
    {
        StandBy,
        InPreparation,
        Started,
        Completed,
        Cancelled
    }
}
