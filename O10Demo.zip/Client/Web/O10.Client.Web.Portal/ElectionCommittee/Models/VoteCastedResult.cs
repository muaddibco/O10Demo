﻿namespace O10.Client.Web.Portal.ElectionCommittee.Models
{
    public class VoteCastedResult
    {
        public bool Result { get; set; }
    }
}
