﻿using O10.Core.Architecture;

namespace O10.Client.Web.Portal
{
    public class TypeRegistrator : TypeRegistratorBase
    {
    }
}
