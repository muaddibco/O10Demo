﻿namespace O10.Client.Web.Portal.Scenarios.Models
{
    public class ScenarioAttributeScheme
    {
        public string AttributeName { get; set; }
        public string AttributeSchemeName { get; set; }
        public string Alias { get; set; }
        public bool CanBeRoot { get; set; }

    }
}
