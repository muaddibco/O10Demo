﻿namespace O10.Client.Web.Portal.Scenarios.Models
{
    public class ScenarioRelation
    {
        public string IssuerId { get; set; }
        public string RootAttribute { get; set; }
        public string Alias { get; set; }
    }
}
