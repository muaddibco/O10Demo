﻿using System.Collections.Generic;

namespace O10.Client.Web.Portal.Scenarios.Models
{
    public class ScenarionIdentity
    {
        public string Alias { get; set; }

        public Dictionary<string, string> Attributes { get; set; }
    }
}
