﻿namespace O10.Client.Web.Portal.Scenarios.Models
{
    public class ScenarioStep
    {
        public int Id { get; set; }
        public string Caption { get; set; }
    }
}
