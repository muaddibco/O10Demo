﻿using System.Collections.Generic;

namespace O10.Client.Web.Portal.Scenarios.Models
{
    public class ScenarioSetup
    {
        public IEnumerable<ScenarioAccount> Accounts { get; set; }
    }
}
