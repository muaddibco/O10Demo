﻿using Microsoft.AspNetCore.Identity;

namespace O10.Client.Web.Portal.IdentityServer.Data.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}
